<?php
include 'services\connection.php';
include 'template\head.php';
$page = "offers";
include 'template\navbar.php';
?>

<div class="container mt-4">

    <table class="table table-striped">
    <thead class="bg-warning">
        <tr>
        <th scope="col">Makeup</th>
        <th scope="col"></th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Pengantin</td>
            <td class="text-left">Rp.750.000</td>
        </tr>
        <tr>
            <td>Wisuda</td>
            <td class="text-left">Rp.250.000</td>
        </tr>
        <tr>
            <td>Wedding</td>
            <td class="text-left">Rp.250.000</td>
        </tr>
        <tr>
            <td>Prewed</td>
            <td class="text-left">Rp.500.000</td>
        </tr>
    </tbody>
    </table>

    <table class="table table-striped">
    <thead class="bg-warning">
        <tr>
        <th scope="col">Make Up & Sanggul</th>
        <th scope="col"></th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Wisuda</td>
            <td class="text-left">Rp.400.000</td>
        </tr>
        <tr>
            <td>Pengantin</td>
            <td class="text-left">Rp.1.000.000</td>
        </tr>
    </tbody>
    </table>

    <table class="table table-striped">
    <thead class="bg-warning">
        <tr>
        <th scope="col">Penyewaan Baju Pengantin & Wisuda</th>
        <th scope="col"></th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Layanan ini akan segera hadir. Akan terus memberi Anda informasi terbaru.</td>
            <td></td>
        </tr>
    </tbody>
    </table>

    <table class="table table-striped">
    <thead class="bg-warning">
        <tr>
        <th scope="col">Untuk Melakukan Pemesanan</th>
        <th scope="col"></th>
        <th scope="col"></th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Anda dapat melakukan pemesanan online dengan masuk ke halaman <a class="text-warning" href="register.php">Situs Website</a>  saya. <br>
            Jangan ragu untuk menghubungi saya untuk pemesanan, konsultasi, pertanyaan lebih lanjut, harga, dan ketersediaan melalui <a class="text-warning" href="contact.php"> Kontak</a> saya.</td>
            <td></td>
            <td></td>
        </tr>
    </tbody>
    </table>

</div>

<?php
include 'template\footer_scripts.php';
?>



<?php
include 'template\footer.php';
?>