
<?php
include 'template\head.php';
$page = "gallery";
include 'template\navbar.php';
?>

<div class="container">

<div class="portfolio-item row mt-4">
    <div class="item makeup col-lg-3 col-md-4 col-6 col-sm ">
        <a href="img/photos/sanggul.jpg" class="fancylight popup-btn" data-fancybox-group="light">
            <img class="img-fluid rounded gallery-img" src="img/photos/sanggul.jpg" alt="">
        </a>
    </div>
    <div class="item makeup col-lg-3 col-md-4 col-6 col-sm">
        <a href="img/photos/makeup.jpg" class="fancylight popup-btn " data-fancybox-group="light">
            <img class="img-fluid rounded gallery-img" src="img/photos/makeup.jpg" alt="">
        </a>
    </div> 
    <div class="item makeup col-lg-3 col-md-4 col-6 col-sm">
        <a href="img/photos/pengantin.jpg" class="fancylight popup-btn" data-fancybox-group="light">
            <img class="img-fluid rounded gallery-img" src="img/photos/pengantin.jpg" alt="">
        </a>
    </div>
    <div class="item makeup col-lg-3 col-md-4 col-6 col-sm">
        <a href="img/photos/pengantin2.jpg" class="fancylight popup-btn" data-fancybox-group="light">
            <img class="img-fluid rounded gallery-img" src="img/photos/pengantin2.jpg" alt="">
        </a>
    </div> 
    <div class="item makeup col-lg-3 col-md-4 col-6 col-sm">
        <a href="img/photos/pengantin3.jpg" class="fancylight popup-btn" data-fancybox-group="light">
            <img class="img-fluid rounded gallery-img" src="img/photos/pengantin3.jpg" alt="">
        </a>
    </div>
    <div class="item makeup col-lg-3 col-md-4 col-6 col-sm">
        <a href="img/photos/pengantin4.jpg" class="fancylight popup-btn" data-fancybox-group="light">
            <img class="img-fluid rounded gallery-img" src="img/photos/pengantin4.jpg" alt="">
        </a>
    </div> 
    <div class="item makeup col-lg-3 col-md-4 col-6 col-sm">
        <a href="img/photos/1.jpg" class="fancylight popup-btn" data-fancybox-group="light">
            <img class="img-fluid rounded gallery-img" src="img/photos/1.jpg" alt="">
        </a>
    </div> 
    <div class="item makeup col-lg-3 col-md-4 col-6 col-sm">
        <a href="img/photos/2.jpg" class="fancylight popup-btn" data-fancybox-group="light">
            <img class="img-fluid rounded gallery-img" src="img/photos/2.jpg" alt="">
        </a>
    </div> 
    <div class="item makeup col-lg-3 col-md-4 col-6 col-sm">
        <a href="img/photos/3.jpg" class="fancylight popup-btn" data-fancybox-group="light">
            <img class="img-fluid rounded gallery-img" src="img/photos/3.jpg" alt="">
        </a>
    </div> 
    <div class="item makeup col-lg-3 col-md-4 col-6 col-sm">
        <a href="img/photos/4.jpg" class="fancylight popup-btn" data-fancybox-group="light">
            <img class="img-fluid rounded gallery-img" src="img/photos/4.jpg" alt="">
        </a>
    </div> 
    <div class="item makeup col-lg-3 col-md-4 col-6 col-sm">
        <a href="img/photos/5.jpg" class="fancylight popup-btn" data-fancybox-group="light">
            <img class="img-fluid rounded gallery-img" src="img/photos/5.jpg" alt="">
        </a>
    </div> 
    <div class="item makeup col-lg-3 col-md-4 col-6 col-sm">
        <a href="img/photos/6.jpg" class="fancylight popup-btn" data-fancybox-group="light">
            <img class="img-fluid rounded gallery-img" src="img/photos/6.jpg" alt="">
        </a>
    </div> 
    </div>
</div><!-- /*Gallery photos container -->


</div><!-- /*Web content container -->

<?php
include 'template\footer_scripts.php';
?>

<script>
    $('.portfolio-menu ul li').click(function() {
        $('.portfolio-menu ul li').removeClass('active');
        $(this).addClass('active');

        var selector = $(this).attr('data-filter');
        $('.portfolio-item').isotope({
            filter: selector
        });
        return false;
    });
    $(document).ready(function() {
        var popup_btn = $('.popup-btn');
        popup_btn.magnificPopup({
            type: 'image',
            gallery: {
                enabled: true
            }
        });
    });
</script><!-- /*Gallery script -->

<?php
include 'template\footer.php';
?>