<?php
include 'services\connection.php';
include 'template\head.php';
$page = "about";
include 'template\navbar.php';
?>

<div class="container">
    <div class="text-center mt-4"><h2>Mega Damayanti <small>Make Up Artist</small></h2></div>
    <div class="row mt-4 container">
    <div class="col-12"><p>Halo! Saya Mega Damayanti, seorang Make Up Artist yang berasal dari kota Jepara, dan lahir pada tanggal 3 Mei 1996. Sejak remaja, saya memiliki ketertarikan besar terhadap dunia kecantikan. Berawal dari hobi merias diri dan teman-teman dekat, saya akhirnya memutuskan untuk menekuni dunia make up secara profesional.</p></div>
        <div class="col-6"><img class="" src="img/aboutmama.jpg" width="100%" alt=""></div>
            <div class="col-6">
                <h5>Make Up Artist</h5>
                <p>Selama beberapa tahun terakhir, saya telah menangani berbagai klien dengan kebutuhan make up yang beragam, mulai dari make up pengantin (wedding), wisuda, pre-wedding (prewedd), hingga make up untuk acara formal dan casual. Saya percaya bahwa setiap wajah memiliki karakter unik, dan tugas saya adalah menonjolkan keindahan alami tersebut melalui teknik rias yang tepat dan pemilihan produk berkualitas. <br>
<br> Fokus utama saya adalah menciptakan tampilan riasan yang natural, elegan, dan tahan lama, sesuai dengan suasana dan tema acara. Saya selalu mengutamakan kenyamanan dan kepuasan klien, dengan melakukan pendekatan personal agar hasil akhirnya sesuai harapan. Tidak hanya membuat cantik, tetapi juga meningkatkan rasa percaya diri mereka.</p>
                
                <h5>Beauty Enthusiast</h5>
                <p>Dengan bekal pengalaman, keahlian, dan semangat belajar yang terus saya jaga, saya siap menjadi bagian dari momen istimewa Anda. Setiap sentuhan kuas yang saya aplikasikan adalah bentuk dedikasi dan cinta terhadap profesi ini. Bagi saya, tidak ada kebahagiaan yang lebih besar daripada melihat senyuman puas di wajah klien. <br>
<br> Saya siap melayani kebutuhan make up di wilayah sekitarnya. Jika Anda sedang mencari MUA untuk acara spesial, jangan ragu untuk menghubungi saya. Mari bersama-sama wujudkan tampilan terbaik Anda di hari yang tak terlupakan.</p>
            </div>
        </div>
        <div class="col-12 mt-4 text-center"><a href="contact.php"><button type="button" class="btn btn-outline-warning mr-2 px-4">Kontak Saya</button></a></div>
    </div>

<?php
include 'template\footer_scripts.php';
?>



<?php
include 'template\footer.php';
?>