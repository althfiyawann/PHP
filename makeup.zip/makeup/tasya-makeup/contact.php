<?php
include 'services\connection.php';
include 'template\head.php';
$page = "contact";
include 'template\navbar.php';
?>

<div class="container">

    <div class="row">
        <div class="col-12 mt-4">
            <div class="card">
                <div class="card-header"><img src="img/icons/envelope-fill.svg" width="18px" alt=""> Hubungi Kami & Alamat
                </div>
                <div class="card-body">
                    <form>
                        <div class="row">
                            <div class="col-12 col-sm-6">
                                <div class="form-group">
                                    <label for="name">Nama</label>
                                    <input type="text" class="form-control" placeholder="Masukkan Nama" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control" placeholder="Masukkan Email" required>
                                </div>
                                <div class="form-group">
                                    <label for="message">Pesan</label>
                                    <textarea class="form-control" id="message" rows="6" required></textarea>
                                </div>
                                <div class="mx-auto">
                                    <button type="submit" class="btn btn-warning text-right">Kirim</button>
                                </div>
                            </div>
                            <div class="col-12 col-sm-6">
                                <div class="card bg-light mb-3">
                                    <div class="card-header"><img src="img/icons/geo-alt.svg" width="18px" alt=""> Alamat</div>
                                    <div class="card-body">
                                        <p><img src="img/icons/house-door-fill.svg" width="18px" alt=""> : Komplek Mabad 1 Jl. Anggur NO.88</p>
                                        <p><img src="img/icons/hash.svg" width="18px" alt=""> : 12640</p>
                                        <p><img src="img/icons/geo.svg" width="18px" alt=""> : Jakarta Selatan</p>
                                        <p><img src="img/icons/at.svg" width="18px" alt="">  : damayantimega6@gmail.com</p>
                                        <p><img src="img/icons/telephone.svg" width="18px" alt=""> : +62 819 0606 5444</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
	
</div>

<?php
include 'template\footer_scripts.php';
?>



<?php
include 'template\footer.php';
?>