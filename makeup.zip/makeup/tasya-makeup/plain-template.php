<?php
include 'services\connection.php';
include 'template\head.php';
$page = "";
include 'template\navbar.php';
?>

<div class="container">
	
</div>

<?php
include 'template\footer_scripts.php';
?>



<?php
include 'template\footer.php';
?>