<?php

    $connection = new mysqli('localhost','root','','makeup');    

    mysqli_set_charset($connection, 'utf8');

?>