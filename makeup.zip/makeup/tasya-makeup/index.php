<?php
include 'template\head.php';
$page = "index";
include 'template\navbar.php';
?>

<div class="imgSmall"></div>

<div class="d-flex vh-100">

    <div class="col-lg-5 text-center last">
        <div class="mb-5 mt-11">
            <h1 class="display-4 mb-3">Riasan Elegan untuk Setiap Momen Berharga</h1>
            <p class="lead">Saya siap membantu Anda tampil memukau dengan sentuhan make up yang natural dan elegan.
            </p>
        </div>

        <a class="btn btn-warning btn-wide transition-3d-hover" href="login.php">Mulai</a>
    </div>

<img src="img/mama.jpg" alt="" class="shift-right">
    </div>

    <hr>

    <div class="container testimonials mb-3 d-flex justify-content-between">

    <div class="testimonialItem">

        <div class="quote quote-sm">
            <blockquote class="quote-blockquote d-flex">
                <p class="quotation-mark">
                    “
                    </p>
                <p class="quote-blockquote-content mt-4 pr-3 pl-1">
                Make up-nya lembut dan tahan lama banget! Aku pakai untuk wisuda dari pagi sampai malam masih flawless. Kak Mega juga ramah dan sangat detail, pokoknya recommended banget!

                <br><br><img src="img/bule1.jpg" alt=""> <span class="small ml-2">Indra</span>
                </p>
            </blockquote>
        </div>                

    </div>
    <div class="testimonialItem">

        <div class="quote quote-sm">
            <blockquote class="quote-blockquote d-flex">
                <p class="quotation-mark">
                    “
                    </p>
                <p class="quote-blockquote-content mt-4 pr-3 pl-1">
                Saya pakai jasa Kak Mega untuk prewed outdoor, dan hasilnya luar biasa! Riasannya cocok dengan wajah saya, nggak menor dan tetap terlihat elegan. Suka banget sama hasilnya!

                <br><br><img src="img/bude.jpg" alt=""> <span class="small ml-2">Wiwik</span>
                </p>
            </blockquote>
        </div>                
    </div>
    <div class="testimonialItem">

        <div class="quote quote-sm">
            <blockquote class="quote-blockquote d-flex">
                <p class="quotation-mark">
                    “
                    </p>
                <p class="quote-blockquote-content mt-4 pr-3 pl-1">
                Di hari pernikahan saya, Kak Mega benar-benar bikin saya merasa jadi versi terbaik dari diri saya sendiri. Make up-nya halus, nggak berat di wajah, semua orang bilang saya cantik.

                <br><br><img src="img/bule2.jpg" alt=""> <span class="small ml-2">Zuli Astuti</span>
                </p>
            </blockquote>
        </div>                
    </div>

    </div>

<?php
include 'template\footer_scripts.php';
?>



<?php
include 'template\footer.php';
?>