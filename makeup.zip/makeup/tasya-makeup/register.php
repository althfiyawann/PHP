<?php
include 'services\connection.php';
require_once 'process.php';
include 'template\head.php';
$page = "register";
include 'template\navbar.php';
?>

<div class="container d-flex justify-content-center align-items-center" style="min-height: 80vh;">

    <div class="card shadow p-4 rounded" style="width: 100%; max-width: 500px;">
        <div class="card-header headerColor text-center fs-4 fw-bold">Daftar</div>
        <div class="card-body">

            <form class="form-horizontal" method="post" action="process.php">

                <div class="mb-3">
                    <label for="name" class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-control" name="name" id="name" placeholder="Masukkan Nama Lengkap" required/>
                </div>

                <div class="mb-3">
                    <label for="surname" class="form-label">Nama Panggilan</label>
                    <input type="text" class="form-control" name="surname" id="surname" placeholder="Masukkan Nama Panggilan" required/>
                </div>

                <div class="mb-3">
                    <label for="birthdate" class="form-label">Tanggal Lahir</label>
                    <input type="date" class="form-control" name="birthdate" id="birthdate" required/>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" name="email" id="email" placeholder="Masukkan Email" required/>
                </div>

                <div class="mb-3">
                    <label for="phone" class="form-label">Nomor Handphone</label>
                    <input type="number" class="form-control" name="phone" id="phone" placeholder="Masukkan Nomor Handphone" />
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Kata Sandi</label>
                    <input type="password" class="form-control" name="password" id="password" placeholder="Masukkan Kata Sandi" required/>
                </div>

                <div class="mb-3">
                    <label for="confirm" class="form-label">Konfirmasi Kata Sandi</label>
                    <input type="password" class="form-control" name="confirm" id="confirm" placeholder="Konfirmasi Kata Sandi" required/>
                </div>

                <div class="d-grid gap-2 mt-3">
                    <button type="submit" name="new_user_register" class="btn btn-warning btn-lg">Daftar</button>
                </div>
            </form>

        </div>
    </div>

</div>

<?php
include 'template\footer_scripts.php';
?>

<?php
include 'template\footer.php';
?>
