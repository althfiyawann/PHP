
	</div>
<footer>
		<div class="d-flex container">
			<div class="col-sm-4 align-self-center">
			</div>

			<div class="col-sm-4 align-self-end">
				<p class="text-nowrap">© Copyright 2015. All rights reserved.</p>
			</div>

			<div class="col-sm-4 socialMediaFooter">
				<a href="#">
					<div class="circleIcon facebookicon"><img src="img/social/facebook.png" alt=""></div>
				</a>
				<a href="#">
					<div class="circleIcon instagramicon"><img src="img/social/instagram.png" alt=""></div>
				</a>
				<a href="#">
					<div class="circleIcon instagramicon"><img src="img/social/social-media.png" alt=""></div>
				</a>
				<a href="#">
					<div class="circleIcon instagramicon"><img src="img/social/linkedin.png" alt=""></div>
				</a>
			</div>
		</div>
	</footer>
</body>

</html>