<?php
include 'template\head.php';
$page = "";
include 'template\navbar.php';

if (isset($_SESSION['valid']) && $_SESSION['valid'] == true && $_SESSION['type'] == "user"){
    header('Location: index.php');
}else if(isset($_SESSION['valid']) && $_SESSION['valid'] == true && $_SESSION['type'] == "admin"){
    header('Location: admin.php');
}else{
}
?>

<div class="container-fluid vh-100 d-flex align-items-center justify-content-center p-0">
    <div class="row w-100 m-0 shadow-lg rounded overflow-hidden" style="max-width: 900px; height: 600px;">
        <div class="col-md-6 d-none d-md-block p-0">
            <div class="h-100 w-100" style="background-image: url('img/photos/pengantin.jpg'); background-size: cover; background-position: center;"></div>
        </div>
<div class="col-md-6 bg-white d-flex flex-column justify-content-center p-5">
            <h2 class="text-center mb-4 fw-bold" style="color: #5a67d8;">Welcome Back</h2>

            <?php
            $msg = '';

            if (isset($_POST['login']) && !empty($_POST['username']) && !empty($_POST['password'])) {

                $email = $_POST['username'];
                $password = $_POST['password'];

                $adminCheck = $connection ->query("SELECT * FROM `admin` WHERE email= '$email' ");

                $counter = mysqli_num_rows($adminCheck);
                
                if($counter == 1){

                    $row = $adminCheck -> fetch_assoc();

                    if($row['password'] != $password){
                            $msg = "Incorrect Password!";
                    }else{
                        $_SESSION['valid'] = true;
                        $_SESSION['type'] = "admin";
                        header('Location: admin.php');
                    }

                }else {

                $sel = $connection->query("SELECT * FROM user WHERE email= '$email' ");

                $counter = mysqli_num_rows($sel);

                    if ($counter == 0) {
                        $msg = "Email doesn't exist!";
                    } else {

                        $fila = $sel->fetch_assoc();

                        if ($fila['password'] != $password) {
                            $msg = "Incorrect Password!";
                        } else {
                            $_SESSION['valid'] = true;
                            $_SESSION['type'] = "user";
                            $_SESSION['user_id'] = $fila['user_id'];
                            header('Location: index.php');
                        }
                    }
                }

            } else if (isset($_POST['login']) && empty($_POST['username'])) {
                $msg = "Email field is empty!";
            } else if (isset($_POST['login']) && empty($_POST['password'])) {
                $msg = "Password field is empty!";
            } else {
            }
            ?>

            <?php if($msg): ?>
                <div class="alert alert-danger text-center"><?php echo $msg; ?></div>
            <?php endif; ?>

            <form role="form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" class="mt-3">
                <div class="mb-3">
                    <label for="email_address" class="form-label">Email</label>
                    <input type="text" id="email_address" class="form-control" name="username" autofocus>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Kata Sandi</label>
                    <input type="password" id="password" class="form-control" name="password">
                </div>

                <div class="form-check mb-3">
                    <input type="checkbox" class="form-check-input" id="remember" name="remember">
                    <label class="form-check-label" for="remember">Ingat Saya</label>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary btn-lg" name="login">Masuk</button>
                </div>

                <div class="mt-3 text-center">
                    <a href="#" class="btn btn-link">Lupa Kata Sandi?</a>
                </div>
            </form>

            <?php if (isset($_SESSION['valid']) && $_SESSION['valid'] == true) : ?>
                <p class="text-center mt-3"><a href="logout.php">Keluar</a></p>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php
include 'template\footer_scripts.php';
?>

<?php
include 'template\footer.php';
?>
